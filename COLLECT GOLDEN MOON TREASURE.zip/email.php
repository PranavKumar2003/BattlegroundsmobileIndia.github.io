<?php
$emailku = 'YOUREMAIL';
?>